"""Core module - Configuration and models"""

from .config import settings

__all__ = ["settings"]
